-- phpMyAdmin SQL Dump
-- version 2.10.2
-- http://www.phpmyadmin.net
-- 
-- 主机: localhost
-- 生成日期: 2014 年 04 月 09 日 06:06
-- 服务器版本: 5.0.45
-- PHP 版本: 5.2.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- 数据库: `korbin`
-- 

-- --------------------------------------------------------

-- 
-- 表的结构 `kor_comment`
-- 

CREATE TABLE `kor_comment` (
  `commentno` int(11) NOT NULL auto_increment,
  `commenttype` varchar(20) NOT NULL default 'essaycomment',
  `targetno` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `commenttext` text,
  `addtime` datetime default NULL,
  `recommentno` int(11) default NULL,
  PRIMARY KEY  (`commentno`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=155 ;

-- 
-- 导出表中的数据 `kor_comment`
-- 

INSERT INTO `kor_comment` VALUES (125, 'essaycomment', 4, 'Joebon', 'test', '2014-03-10 13:03:14', NULL);
INSERT INTO `kor_comment` VALUES (126, 'workcomment', 5, 'Joebon', 'test', '2014-03-10 13:03:37', NULL);
INSERT INTO `kor_comment` VALUES (127, 'workcomment', 5, 'Joebon', 'test', '2014-03-10 13:03:52', NULL);
INSERT INTO `kor_comment` VALUES (128, 'experiencecomment', 3, 'Joebon', 'sdfsdf', '2014-03-10 13:03:24', NULL);
INSERT INTO `kor_comment` VALUES (129, 'workcomment', 5, 'Joebon', 'sdfsdfsdf', '2014-03-10 13:03:29', NULL);
INSERT INTO `kor_comment` VALUES (130, 'experiencecomment', 3, 'Joebon', 'dsfdsfsdf', '2014-03-10 13:03:36', NULL);
INSERT INTO `kor_comment` VALUES (131, 'experiencecomment', 3, 'Joebon', 'dfgdfg', '2014-03-10 13:03:46', NULL);
INSERT INTO `kor_comment` VALUES (132, 'experiencecomment', 3, 'Joebon', 'test', '2014-03-10 13:03:47', NULL);
INSERT INTO `kor_comment` VALUES (133, 'experiencecomment', 6, 'Joebon', 'sdfsdfds', '2014-03-10 13:03:05', NULL);
INSERT INTO `kor_comment` VALUES (134, 'experiencecomment', 6, 'Joebon', 'sdfsdfsdfsdfsd', '2014-03-10 13:03:11', NULL);
INSERT INTO `kor_comment` VALUES (135, 'workcomment', 5, 'Joebon', '66666666', '2014-03-10 13:03:18', NULL);
INSERT INTO `kor_comment` VALUES (136, 'workcomment', 5, 'Joebon', '7777777777', '2014-03-10 13:03:56', NULL);
INSERT INTO `kor_comment` VALUES (137, 'workcomment', 5, 'Joebon', '88888888', '2014-03-10 14:03:18', NULL);
INSERT INTO `kor_comment` VALUES (138, 'workcomment', 5, 'Joebon', '99999999', '2014-03-10 14:03:11', NULL);
INSERT INTO `kor_comment` VALUES (139, 'workcomment', 5, 'Joebon', '1111111111111111111111111', '2014-03-10 14:03:34', NULL);
INSERT INTO `kor_comment` VALUES (140, 'workcomment', 4, 'Joebon', '1234454555', '2014-03-24 19:03:20', NULL);
INSERT INTO `kor_comment` VALUES (141, 'workcomment', 4, 'zbin', '打工行', '2014-03-24 19:03:42', NULL);
INSERT INTO `kor_comment` VALUES (142, 'essaycomment', 2, 'Joebon', '啥地方撒旦v', '2014-03-24 19:03:59', NULL);
INSERT INTO `kor_comment` VALUES (143, 'essaycomment', 1, 'Joebon', '到上辅导班', '2014-03-24 19:03:12', NULL);
INSERT INTO `kor_comment` VALUES (144, 'essaycomment', 1, 'Joebon', '1233444555', '2014-03-24 19:03:30', NULL);
INSERT INTO `kor_comment` VALUES (145, 'workcomment', 4, 'Joebon', '1234', '2014-03-24 19:03:43', NULL);
INSERT INTO `kor_comment` VALUES (146, 'experiencecomment', 3, 'Joebon', '456576', '2014-03-24 19:03:53', NULL);
INSERT INTO `kor_comment` VALUES (147, 'experiencecomment', 3, 'Joebon', 'sdf', '2014-03-24 19:03:48', NULL);
INSERT INTO `kor_comment` VALUES (148, 'essaycomment', 2, 'Joebon', '上鼎飞丹砂v刹地方v', '2014-03-24 19:03:59', NULL);
INSERT INTO `kor_comment` VALUES (149, 'essaycomment', 2, 'Joebon', '123345566677', '2014-03-24 19:03:52', NULL);
INSERT INTO `kor_comment` VALUES (150, 'experiencecomment', 3, 'Joebon', '三等功vfdbsgf', '2014-03-24 19:03:27', NULL);
INSERT INTO `kor_comment` VALUES (151, 'workcomment', 4, 'zbin', '4566777', '2014-03-26 08:03:37', NULL);
INSERT INTO `kor_comment` VALUES (152, 'essaycomment', 2, 'zbin', '法规和共和国', '2014-03-26 08:03:57', NULL);
INSERT INTO `kor_comment` VALUES (153, 'workcomment', 4, 'korbin', 'test', '2014-03-26 09:03:12', NULL);
INSERT INTO `kor_comment` VALUES (154, 'essaycomment', 1, 'zbin', '的说法格式规范 ', '2014-03-26 12:03:40', NULL);

-- --------------------------------------------------------

-- 
-- 表的结构 `kor_message`
-- 

CREATE TABLE `kor_message` (
  `messageno` int(11) NOT NULL auto_increment,
  `message_author` varchar(20) NOT NULL,
  `message_title` text,
  `message_text` text,
  `comment_user` varchar(20) NOT NULL,
  `comment_targetno` int(12) NOT NULL,
  `prodouction_type` varchar(20) NOT NULL,
  PRIMARY KEY  (`messageno`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

-- 
-- 导出表中的数据 `kor_message`
-- 

INSERT INTO `kor_message` VALUES (13, 'Joebon', '张志东辞任腾讯CTO邮件 马化腾动情回复', '的说法格式规范 ', 'zbin', 1, 'Essay');

-- --------------------------------------------------------

-- 
-- 表的结构 `kor_post`
-- 

CREATE TABLE `kor_post` (
  `editno` int(11) NOT NULL auto_increment,
  `postname` varchar(200) NOT NULL,
  `industry` varchar(50) NOT NULL,
  `author` varchar(20) default NULL,
  `addtime` datetime default NULL,
  `editpart` varchar(20) NOT NULL default 'introduction',
  `content` text,
  `score` int(11) default NULL,
  `formal` varchar(10) NOT NULL default 'false',
  PRIMARY KEY  (`editno`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=18 ;

-- 
-- 导出表中的数据 `kor_post`
-- 

INSERT INTO `kor_post` VALUES (1, '前端开发工程师', '23', 'joebon', '2014-03-29 14:59:27', 'introduction', '似懂非懂', 23, 'true');
INSERT INTO `kor_post` VALUES (2, '前端开发工程师', '34', 'joebon', '2014-03-04 14:59:54', 'requirement', 'sdf', 34, 'true');
INSERT INTO `kor_post` VALUES (3, '前端开发工程师', 'divcss', 'Joebon', '2014-03-23 16:03:29', 'improvement', '<p>似懂非懂</p>', NULL, 'true');
INSERT INTO `kor_post` VALUES (4, '前端开发工程师', 'divcss', 'Joebon', '2014-03-23 16:03:16', 'employment', '<p>似懂非懂啥地方刚v</p>', 0, 'true');
INSERT INTO `kor_post` VALUES (5, '前端开发工程师', 'divcss', 'Joebon', '2014-03-23 16:03:54', 'introduction', '<p>似懂非懂77</p>', NULL, 'false');
INSERT INTO `kor_post` VALUES (6, '技术支持工程师', 'divcss', 'Joebon', '2014-03-23 17:03:52', 'introduction', NULL, NULL, 'false');
INSERT INTO `kor_post` VALUES (7, '前端开发工程师', 'divcss', 'zbin', '2014-03-23 18:03:54', 'introduction', '<p>似懂非懂1</p>', NULL, 'false');
INSERT INTO `kor_post` VALUES (8, '会计', 'javascript', 'Joebon', '2014-04-07 19:04:42', 'introduction', NULL, NULL, 'false');
INSERT INTO `kor_post` VALUES (9, '测试工程师', 'divcss', 'Joebon', '2014-04-07 19:04:16', 'introduction', NULL, NULL, 'false');
INSERT INTO `kor_post` VALUES (10, '软件工程师', 'divcss', 'Joebon', '2014-04-07 20:04:48', 'introduction', '<p>师德师风松岛枫松岛枫</p>', NULL, 'true');
INSERT INTO `kor_post` VALUES (11, '软件工程师', 'divcss', 'Joebon', '2014-04-07 20:04:48', 'requirement', '<p>松岛枫松岛枫是</p>', NULL, 'true');
INSERT INTO `kor_post` VALUES (12, '软件工程师', 'divcss', 'Joebon', '2014-04-07 20:04:48', 'improvement', '<p>松岛枫随碟附送的发</p>', NULL, 'true');
INSERT INTO `kor_post` VALUES (13, '软件工程师', 'divcss', 'Joebon', '2014-04-07 20:04:48', 'employment', '<p>随碟附送的飞</p>', NULL, 'true');
INSERT INTO `kor_post` VALUES (14, '产品经理', 'divcss', 'Joebon', '2014-04-08 11:04:45', 'introduction', '<p>产品经理产品经理产品经理</p>', NULL, 'false');
INSERT INTO `kor_post` VALUES (15, '产品经理', 'divcss', 'Joebon', '2014-04-08 11:04:45', 'requirement', '<p>产品经理产品经理</p>', NULL, 'false');
INSERT INTO `kor_post` VALUES (16, '产品经理', 'divcss', 'Joebon', '2014-04-08 11:04:45', 'improvement', '<p>产品经理</p>', NULL, 'false');
INSERT INTO `kor_post` VALUES (17, '产品经理', 'divcss', 'Joebon', '2014-04-08 11:04:45', 'employment', '<p>产品经理产品经理产品经理产品经理产品经理</p>', NULL, 'false');

-- --------------------------------------------------------

-- 
-- 表的结构 `kor_praise`
-- 

CREATE TABLE `kor_praise` (
  `praiseno` int(11) NOT NULL auto_increment,
  `praisetype` varchar(20) NOT NULL default 'essaypraise',
  `targetno` int(11) NOT NULL,
  `author` varchar(20) NOT NULL,
  `targetauthor` varchar(20) NOT NULL,
  `addtime` datetime default NULL,
  `positive` varchar(10) NOT NULL default 'false',
  PRIMARY KEY  (`praiseno`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=169 ;

-- 
-- 导出表中的数据 `kor_praise`
-- 

INSERT INTO `kor_praise` VALUES (131, 'postpraise', 2, 'zbin', '', '2014-03-26 08:03:30', 'true');
INSERT INTO `kor_praise` VALUES (130, 'postpraise', 1, 'zbin', '', '2014-03-26 08:03:28', 'false');
INSERT INTO `kor_praise` VALUES (129, 'postpraise', 4, 'zbin', '', '2014-03-26 08:03:13', 'true');
INSERT INTO `kor_praise` VALUES (128, 'postpraise', 3, 'zbin', '', '2014-03-26 08:03:11', 'true');
INSERT INTO `kor_praise` VALUES (127, 'postpraise', 2, 'zbin', '', '2014-03-26 08:03:04', 'true');
INSERT INTO `kor_praise` VALUES (126, 'postpraise', 2, 'zbin', '', '2014-03-26 08:03:00', 'true');
INSERT INTO `kor_praise` VALUES (125, 'postpraise', 2, 'zbin', '', '2014-03-26 08:03:50', 'true');
INSERT INTO `kor_praise` VALUES (124, 'postpraise', 3, 'zbin', '', '2014-03-26 08:03:48', 'true');
INSERT INTO `kor_praise` VALUES (123, 'postpraise', 4, 'zbin', '', '2014-03-26 08:03:45', 'true');
INSERT INTO `kor_praise` VALUES (122, 'postpraise', 4, 'zbin', '', '2014-03-26 08:03:44', 'false');
INSERT INTO `kor_praise` VALUES (121, 'postpraise', 4, 'zbin', '', '2014-03-26 08:03:42', 'false');
INSERT INTO `kor_praise` VALUES (120, 'postpraise', 3, 'zbin', '', '2014-03-26 08:03:40', 'false');
INSERT INTO `kor_praise` VALUES (119, 'postpraise', 2, 'zbin', '', '2014-03-26 08:03:38', 'false');
INSERT INTO `kor_praise` VALUES (118, 'postpraise', 1, 'zbin', '', '2014-03-26 08:03:34', 'false');
INSERT INTO `kor_praise` VALUES (117, 'workpraise', 4, 'zbin', 'Joebon', '2014-03-25 21:03:18', 'true');
INSERT INTO `kor_praise` VALUES (116, 'workpraise', 4, 'zbin', 'Joebon', '2014-03-25 21:03:17', 'false');
INSERT INTO `kor_praise` VALUES (115, 'workpraise', 4, 'zbin', 'Joebon', '2014-03-25 21:03:15', 'true');
INSERT INTO `kor_praise` VALUES (114, 'postpraise', 1, 'Joebon', '', '2014-03-23 17:03:40', 'false');
INSERT INTO `kor_praise` VALUES (113, 'postpraise', 1, 'Joebon', '', '2014-03-23 17:03:39', 'false');
INSERT INTO `kor_praise` VALUES (112, 'postpraise', 1, 'Joebon', '', '2014-03-23 17:03:37', 'true');
INSERT INTO `kor_praise` VALUES (111, 'postpraise', 1, 'Joebon', '', '2014-03-23 17:03:36', 'true');
INSERT INTO `kor_praise` VALUES (110, 'postpraise', 1, 'Joebon', '', '2014-03-23 17:03:50', 'false');
INSERT INTO `kor_praise` VALUES (109, 'postpraise', 1, 'Joebon', '', '2014-03-23 17:03:49', 'true');
INSERT INTO `kor_praise` VALUES (108, 'postpraise', 1, 'Joebon', '', '2014-03-23 17:03:44', 'true');
INSERT INTO `kor_praise` VALUES (107, 'postpraise', 1, 'Joebon', '', '2014-03-23 17:03:40', 'true');
INSERT INTO `kor_praise` VALUES (106, 'postpraise', 1, 'Joebon', '', '2014-03-23 17:03:38', 'true');
INSERT INTO `kor_praise` VALUES (105, 'postpraise', 1, 'Joebon', '', '2014-03-23 17:03:36', 'true');
INSERT INTO `kor_praise` VALUES (104, 'postpraise', 1, 'Joebon', '', '2014-03-23 17:03:29', 'false');
INSERT INTO `kor_praise` VALUES (103, 'postpraise', 1, 'Joebon', '', '2014-03-23 17:03:27', 'true');
INSERT INTO `kor_praise` VALUES (102, 'postpraise', 1, 'Joebon', '', '2014-03-23 17:03:40', 'true');
INSERT INTO `kor_praise` VALUES (45, 'experiencepraise', 32, 'korbin', 'Joebon', '2014-03-10 01:03:04', 'true');
INSERT INTO `kor_praise` VALUES (46, 'experiencepraise', 32, 'korbin', 'Joebon', '2014-03-10 01:03:05', 'false');
INSERT INTO `kor_praise` VALUES (47, 'experiencepraise', 32, 'korbin', 'Joebon', '2014-03-10 01:03:06', 'false');
INSERT INTO `kor_praise` VALUES (48, 'experiencepraise', 32, 'korbin', 'Joebon', '2014-03-10 01:03:07', 'true');
INSERT INTO `kor_praise` VALUES (49, 'experiencepraise', 32, 'korbin', 'Joebon', '2014-03-10 01:03:30', 'false');
INSERT INTO `kor_praise` VALUES (50, 'experiencepraise', 32, 'korbin', 'Joebon', '2014-03-10 01:03:31', 'true');
INSERT INTO `kor_praise` VALUES (51, 'experiencepraise', 32, 'korbin', 'Joebon', '2014-03-10 01:03:08', 'true');
INSERT INTO `kor_praise` VALUES (52, 'experiencepraise', 32, 'korbin', 'Joebon', '2014-03-10 01:03:09', 'true');
INSERT INTO `kor_praise` VALUES (53, 'essaypraise', 217, 'korbin', 'Joebon', '2014-03-10 01:03:39', 'true');
INSERT INTO `kor_praise` VALUES (54, 'essaypraise', 217, 'korbin', 'Joebon', '2014-03-10 01:03:40', 'false');
INSERT INTO `kor_praise` VALUES (55, 'essaypraise', 217, 'korbin', 'Joebon', '2014-03-10 01:03:45', 'true');
INSERT INTO `kor_praise` VALUES (56, 'essaypraise', 217, 'korbin', 'Joebon', '2014-03-10 01:03:46', 'true');
INSERT INTO `kor_praise` VALUES (57, 'essaypraise', 217, 'korbin', 'Joebon', '2014-03-10 01:03:47', 'true');
INSERT INTO `kor_praise` VALUES (58, 'essaypraise', 217, 'korbin', 'Joebon', '2014-03-10 01:03:48', 'false');
INSERT INTO `kor_praise` VALUES (59, 'essaypraise', 217, 'korbin', 'Joebon', '2014-03-10 04:03:16', 'false');
INSERT INTO `kor_praise` VALUES (60, 'essaypraise', 217, 'korbin', 'Joebon', '2014-03-10 04:03:17', 'false');
INSERT INTO `kor_praise` VALUES (61, 'essaypraise', 217, 'korbin', 'Joebon', '2014-03-10 04:03:18', 'true');
INSERT INTO `kor_praise` VALUES (62, 'essaypraise', 217, 'korbin', 'Joebon', '2014-03-10 04:03:19', 'true');
INSERT INTO `kor_praise` VALUES (63, 'workpraise', 1, 'korbin', '', '2014-03-10 05:03:39', 'true');
INSERT INTO `kor_praise` VALUES (64, 'workpraise', 1, 'korbin', '', '2014-03-10 05:03:40', 'false');
INSERT INTO `kor_praise` VALUES (65, 'workpraise', 1, 'korbin', '', '2014-03-10 05:03:40', 'false');
INSERT INTO `kor_praise` VALUES (66, 'workpraise', 1, 'korbin', '', '2014-03-10 05:03:41', 'false');
INSERT INTO `kor_praise` VALUES (67, 'workpraise', 1, 'korbin', '', '2014-03-10 05:03:41', 'false');
INSERT INTO `kor_praise` VALUES (68, 'workpraise', 1, 'korbin', '', '2014-03-10 05:03:42', 'true');
INSERT INTO `kor_praise` VALUES (69, 'workpraise', 1, 'korbin', '', '2014-03-10 05:03:42', 'true');
INSERT INTO `kor_praise` VALUES (70, 'workpraise', 1, 'korbin', '', '2014-03-10 05:03:42', 'true');
INSERT INTO `kor_praise` VALUES (71, 'workpraise', 1, 'korbin', '', '2014-03-10 05:03:44', 'true');
INSERT INTO `kor_praise` VALUES (72, 'workpraise', 1, 'korbin', '', '2014-03-10 05:03:45', 'false');
INSERT INTO `kor_praise` VALUES (73, 'experiencepraise', 6, 'korbin', 'Joebon', '2014-03-10 14:03:31', 'false');
INSERT INTO `kor_praise` VALUES (74, 'experiencepraise', 6, 'korbin', 'Joebon', '2014-03-10 14:03:32', 'true');
INSERT INTO `kor_praise` VALUES (75, 'experiencepraise', 6, 'korbin', 'Joebon', '2014-03-10 14:03:34', 'true');
INSERT INTO `kor_praise` VALUES (76, 'experiencepraise', 6, 'korbin', 'Joebon', '2014-03-10 14:03:35', 'true');
INSERT INTO `kor_praise` VALUES (77, 'postpraise', 0, 'Joebon', '', '2014-03-23 16:03:33', 'true');
INSERT INTO `kor_praise` VALUES (100, 'postpraise', 1, 'zbin', 'Joebon', '2014-03-04 16:57:30', 'true');
INSERT INTO `kor_praise` VALUES (101, 'postpraise', 1, 'zbin', 'joebon', '2014-03-12 16:57:59', 'false');
INSERT INTO `kor_praise` VALUES (132, 'postpraise', 2, 'zbin', '', '2014-03-26 08:03:31', 'false');
INSERT INTO `kor_praise` VALUES (133, 'postpraise', 1, 'zbin', '', '2014-03-26 08:03:36', 'false');
INSERT INTO `kor_praise` VALUES (134, 'postpraise', 2, 'zbin', '', '2014-03-26 08:03:44', 'true');
INSERT INTO `kor_praise` VALUES (135, 'postpraise', 2, 'zbin', '', '2014-03-26 08:03:45', 'false');
INSERT INTO `kor_praise` VALUES (136, 'postpraise', 3, 'zbin', '', '2014-03-26 08:03:46', 'true');
INSERT INTO `kor_praise` VALUES (137, 'postpraise', 3, 'zbin', '', '2014-03-26 08:03:47', 'false');
INSERT INTO `kor_praise` VALUES (138, 'postpraise', 4, 'zbin', '', '2014-03-26 08:03:49', 'true');
INSERT INTO `kor_praise` VALUES (139, 'postpraise', 4, 'zbin', '', '2014-03-26 08:03:50', 'false');
INSERT INTO `kor_praise` VALUES (140, 'postpraise', 1, 'zbin', '', '2014-03-26 08:03:24', 'true');
INSERT INTO `kor_praise` VALUES (141, 'postpraise', 1, 'zbin', '', '2014-03-26 08:03:25', 'false');
INSERT INTO `kor_praise` VALUES (142, 'postpraise', 1, 'zbin', '', '2014-03-26 08:03:27', 'true');
INSERT INTO `kor_praise` VALUES (143, 'postpraise', 1, 'zbin', '', '2014-03-26 08:03:28', 'false');
INSERT INTO `kor_praise` VALUES (144, 'postpraise', 1, 'Joebon', '', '2014-03-26 09:03:53', 'true');
INSERT INTO `kor_praise` VALUES (145, 'postpraise', 1, 'Joebon', '', '2014-03-26 09:03:54', 'true');
INSERT INTO `kor_praise` VALUES (146, 'postpraise', 1, 'Joebon', '', '2014-03-26 09:03:55', 'true');
INSERT INTO `kor_praise` VALUES (147, 'postpraise', 1, 'Joebon', '', '2014-03-26 09:03:56', 'true');
INSERT INTO `kor_praise` VALUES (148, 'postpraise', 1, 'Joebon', '', '2014-03-26 09:03:57', 'true');
INSERT INTO `kor_praise` VALUES (149, 'postpraise', 1, 'Joebon', '', '2014-03-26 09:03:58', 'false');
INSERT INTO `kor_praise` VALUES (150, 'postpraise', 1, 'Joebon', '', '2014-03-26 09:03:00', 'false');
INSERT INTO `kor_praise` VALUES (151, 'postpraise', 1, 'Joebon', '', '2014-03-26 09:03:01', 'false');
INSERT INTO `kor_praise` VALUES (152, 'postpraise', 2, 'Joebon', '', '2014-03-26 09:03:02', 'false');
INSERT INTO `kor_praise` VALUES (153, 'postpraise', 2, 'Joebon', '', '2014-03-26 09:03:03', 'false');
INSERT INTO `kor_praise` VALUES (154, 'postpraise', 2, 'Joebon', '', '2014-03-26 09:03:04', 'false');
INSERT INTO `kor_praise` VALUES (155, 'postpraise', 2, 'Joebon', '', '2014-03-26 09:03:05', 'true');
INSERT INTO `kor_praise` VALUES (156, 'postpraise', 2, 'Joebon', '', '2014-03-26 09:03:05', 'true');
INSERT INTO `kor_praise` VALUES (157, 'postpraise', 2, 'Joebon', '', '2014-03-26 09:03:06', 'true');
INSERT INTO `kor_praise` VALUES (158, 'postpraise', 2, 'Joebon', '', '2014-03-26 09:03:07', 'true');
INSERT INTO `kor_praise` VALUES (159, 'postpraise', 2, 'Joebon', '', '2014-03-26 09:03:09', 'false');
INSERT INTO `kor_praise` VALUES (160, 'postpraise', 2, 'Joebon', '', '2014-03-26 09:03:10', 'true');
INSERT INTO `kor_praise` VALUES (161, 'postpraise', 2, 'Joebon', '', '2014-03-26 09:03:18', 'true');
INSERT INTO `kor_praise` VALUES (162, 'postpraise', 2, 'Joebon', '', '2014-03-26 09:03:18', 'true');
INSERT INTO `kor_praise` VALUES (163, 'postpraise', 2, 'Joebon', '', '2014-03-26 09:03:18', 'true');
INSERT INTO `kor_praise` VALUES (164, 'postpraise', 2, 'Joebon', '', '2014-03-26 09:03:19', 'true');
INSERT INTO `kor_praise` VALUES (165, 'postpraise', 2, 'Joebon', '', '2014-03-26 09:03:19', 'true');
INSERT INTO `kor_praise` VALUES (166, 'postpraise', 2, 'Joebon', '', '2014-03-26 09:03:19', 'true');
INSERT INTO `kor_praise` VALUES (167, 'postpraise', 2, 'Joebon', '', '2014-03-26 09:03:19', 'true');
INSERT INTO `kor_praise` VALUES (168, 'postpraise', 2, 'Joebon', '', '2014-03-26 09:03:19', 'true');

-- --------------------------------------------------------

-- 
-- 表的结构 `kor_production`
-- 

CREATE TABLE `kor_production` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(200) NOT NULL,
  `type` varchar(50) NOT NULL,
  `industry` varchar(50) NOT NULL,
  `author` varchar(20) default NULL,
  `addtime` datetime default NULL,
  `summary` text,
  `content` text,
  `attachment` varchar(100) default NULL,
  `commentscount` int(11) NOT NULL default '0',
  `visits` int(11) NOT NULL default '0',
  `checked` varchar(10) NOT NULL default 'false',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=22 ;

-- 
-- 导出表中的数据 `kor_production`
-- 

INSERT INTO `kor_production` VALUES (1, '张志东辞任腾讯CTO邮件 马化腾动情回复', 'Essay', 'divcss', 'Joebon', '2014-03-23 09:03:55', '<div class="con_title">\r\n<p><code>3月19日消息，腾讯核心创始人之一、执行董事及首席技术官(CTO)张志东将在3月20日和9月20日，先后辞去所担任的执行董事和CTO职务。</code></p>\r\n</div>\r\n<div class="con_txt clx">\r\n<p><a class="fancybox" href="http://image.woshipm.com/wp-files/2014/03/21155J2V_0.jpg" data-fancybox-group="gallery"><img class="alignnone size-full wp-image-74523 aligncenter" src="http://image.woshipm.com/wp-files/2014/03/21155J2V_0.jpg" alt="张志东离职邮件" width="506" height="322" /></a></p>\r\n<p>在今日下午腾讯正式发布此次公告之后，马化腾和张志东的内部邮件也被曝光。张志东在给员工的邮件中表示，&ldquo;近几年来，身体状况不太好，体力和精力成为一个大瓶颈。&rdquo;透露出两年前就提出过辞任的想法，但在马化腾的劝说下留任至今。</p>\r\n</div>', '<div class="con_title">\r\n<p><code>3月19日消息，腾讯核心创始人之一、执行董事及首席技术官(CTO)张志东将在3月20日和9月20日，先后辞去所担任的执行董事和CTO职务。</code></p>\r\n</div>\r\n<div class="con_txt clx">\r\n<p><a class="fancybox" href="http://image.woshipm.com/wp-files/2014/03/21155J2V_0.jpg" data-fancybox-group="gallery"><img class="alignnone size-full wp-image-74523 aligncenter" src="http://image.woshipm.com/wp-files/2014/03/21155J2V_0.jpg" alt="张志东离职邮件" width="640" height="412" /></a></p>\r\n<p>在今日下午腾讯正式发布此次公告之后，马化腾和张志东的内部邮件也被曝光。张志东在给员工的邮件中表示，&ldquo;近几年来，身体状况不太好，体力和精力成为一个大瓶颈。&rdquo;透露出两年前就提出过辞任的想法，但在马化腾的劝说下留任至今。</p>\r\n<p>以下为马化腾对张志东辞任CTO一事发给全体员工邮件：</p>\r\n<p><strong>　各位同事：</strong></p>\r\n<blockquote>\r\n<p>今天，我怀着很复杂的心情回复关于Tony的这个邮件。Tony在两年多前就对总办提出了这个请求，也特别和我们整个创业团队进行了反复沟通，在公司业务的变革挑战下，在团队特别需要时，他又留下来与我们高强度地并肩战斗了两年。今天，我首先代表全体总办、全体腾讯人对Tony过去16年来所做的一切、特别是过去两年多的继续担当表示由衷的感谢！对Tony转身成为腾讯学院的一名讲师，专注于他一直非常执着和热爱的技术人才培养工作，我也由衷地为他感到高兴。</p>\r\n<p>我与Tony的感情不仅于此，4年的大学同窗，16年的创业伙伴，我们一起共度了比家人还要长的时光。这样的经历，这样的感情，用什么语言去描述都是很难尽述。回想当年，踏入社会工作数年，因我俩都刚好是国内为数不多的互联网寻呼系统的开发者之一，且有着共同的梦想，才有了腾讯创业的开始。</p>\r\n<p>创业初期、直到创业多年以后，Tony都是我们首要依赖的一线技术专家，也是大家的技术主心骨，为腾讯互联网海量服务能力奠定了深厚的技术基础。今天，Tony依然从未间断过对公司技术发展的关注和指导、高度重视人才的培养，哪怕是选择了退出管理岗位，仍然希望坚持这一爱好，留在公司做技术顾问和学院讲师。</p>\r\n<p>比技术本身更为重要的是，Tony是公司用户价值观的最坚持的践行人。在总办会议上，Tony是最能站在用户角度毫不妥协的人，始终保持着这份&ldquo;固执&rdquo;。Tony这份坚持，也融入了公司的强用户导向的理念基因。</p>\r\n<p>很多事说再多，都不如自己亲自做。Tony在过去16年中，始终如一为理想而固执，是很多同事们的好领导、好朋友。这些行为也感染到了我们的创业团队，感染到每一个和Tony打过交道的同事，这些不是纸面上的文字可以呈现的。</p>\r\n<p>过去两年，Tony考虑到自己将要逐步放下管理工作，在继续支持公司业务的同时，把很多精力放在了培养接班人、延续公司文化等方面，这些工作的价值会在未来的工作中体现，也是公司要继续坚持下去的重要方向。</p>\r\n<p>好在Tony的爱好仍然是技术，仍然是传道授业，仍然会在公司担任终身荣誉顾问、学院讲师和文化大使，总办和同事们仍然可以和Tony在一起工作和一起交流。我们尊重Tony的选择，也清晰地记得Tony一直强调的一句话：&ldquo;不一定非要在管理层才能对公司有贡献，任何一个员工，都可以为公司发光发热。&rdquo;。相信Tony也能继续在公司内部致力于自己的爱好，并且让事业和生活更加平衡。</p>\r\n<p>最后，还是要对Tony再说一次感谢，代表我自己、更是代表同事们感谢Tony。你不仅仅是公司过去16年的CTO，更是一个天真、执着、善良和可敬的良师益友。无论在任何岗位，你都是腾讯人心中的好伙伴！</p>\r\n<p>Pony</p>\r\n<p>2014.3.19</p>\r\n</blockquote>\r\n<p><strong>　　以下为张志东群发邮件：</strong></p>\r\n<blockquote>\r\n<p>各位同事，</p>\r\n<p>我怀着感恩和欣慰的心情在写这封信，我将辞任腾讯公司管理层和董事会的工作。在公司永不停息的发展和努力奋斗中，不知不觉已走过十六个年头，从27岁走到43岁，这是我人生中最值得珍视的日子，我和所有腾讯人一起，见证并参与了中国互联网大潮，伴随团队一起成长，这让我的职业生涯感到特别开心。</p>\r\n<p><strong>　　对交棒接力的思考</strong></p>\r\n<p>我不是一个能力全面的人，领导力不是我的强项，在一家过两万人的企业里任职管理层，我有很多不足之处。加上近几年来，身体状况不太好，体力和精力成为一个大瓶颈。我深知公司所处是一个日新月异的行业，需要领导者全心投入和充沛精力，决不可以倚老卖老。我一直很希望，可以在公司培养出更全面的技术领导人，可以接替我更好地带领公司走向未来。</p>\r\n<p>2年前我开始和Pony、Martin深入沟通我的想法，经过多次深入沟通，我们达成了一致。用两年的时间，在公司向移动互联网转型的过程中，帮助技术领军同事成长和完成交棒接力的过程。</p>\r\n<p>很开心看到，经过多年的融合实战锻炼，公司的管理团队已有很长足的进步。Ls带领的TEG，Mark/Dowson带领的IEG/MIG/SNG，Allenzhang带领的微信团队，这两年来取得重大进展，完成了面向移动互联网的关键组织变革。他们几位和团队一起风雨同行多年，无论在技术能力，在带领团队的领导力上，特别在企业文化上，都已取得团队的高度认同，他们已能很好的接棒。正因为伙伴们的良好成长和组织的进一步成熟，使得我可以有机会很放心地离任管理层，更换一种生活节奏。</p>\r\n<p>离任管理层之后，我新的工作是将是腾讯学院的培训讲师，致力于公司技术理念和文化理念的传承工作。在帮助公司技术产品的同事成长助力上，一直是我未完成的心愿和兴趣所在。原来在管理层的工作太忙，很惭愧在这里花在腾讯学院的时间很少，贡献也少。希望退下管理层之后，可以有更多时间完成这个心愿。</p>\r\n<p><strong>　　对团队的感恩</strong></p>\r\n<p>十六年前，Pony和我在做IT工程师，我们有一个梦想，梦想我们可以做一个互联网产品给很多人用，同时可以养活自己。因为一个朴素的梦想，因为创业伙伴之间的相互鼓励，我们开始了腾讯的创业之旅。一个小公司能否凭技术和服务能生存下来?我们完全没有把握。</p>\r\n<p>幸运的是我们遇上了中国互联网大发展的浪潮，深圳这座改革开放的窗口城市，具有浓厚的创业气氛,出于对互联网的热衷，我们一头撞进了互联网这个新兴行业。</p>\r\n<p>感恩创业伙伴和管理团队，我的个性比较急躁和固执，能力不全面。是创业伙伴们对我的包容，让我可以发挥所长，修正我的缺点，帮助我成长。在公司发展的过程中，遇到过很多难关，难免经常有激烈的争论，但腾讯的管理团队一直具有很强的包容性，可以包容多种个性的伙伴，相互扶持，凝聚力量。能和这样的伙伴一起共事一起成长，是我的幸运。</p>\r\n<p>感恩所有的腾讯同事。在许多同事身上，我感受到十年如一日的热忱和坚持。要做好互联网服务是挺苦挺累的事情，新事物、新问题层出不穷，用户的期望不断在提升，团队每天奔忙于各类改进，时刻面对各类突发事件，为了不让用户失望，腾讯人十年如一日用心的投入。许多可敬可爱的同事，他们并不仅仅是在做一份工作，而是用心做一份事业，用心帮助身边的同事。在他们身上，可以让人感受到团队的魅力。在公司的每一天，我都可以感受到腾讯人的正气和朝气，每天都能感受到工作的快乐。</p>\r\n<p><strong>　　对腾讯未来的期许</strong></p>\r\n<p>公司发展的每个历史阶段，都必然会面临新问题和新挑战。我最关心的并不是业务得失成败，而是团队文化的凝聚。在我看来，一项业务受挫了，我们还可以重新再来。能让腾讯人全心投入，努力奋斗的原因，并不是公司收入、市场份额、股票升跌这些外在因素，而是这里有一群志同道合的人和气场，小伙伴们具有共同的价值观，渴望通过技术和产品改变世界。</p>\r\n<p>移动互联网的大潮，将催生前所未有的创新机遇和前所未有的挑战。腾讯必然会遇到许多艰难险阻，期望腾讯人能时刻在意用户感受，永远对用户体验战战兢兢，永远对社会、对行业持敬畏之心，期望腾讯人能打造出让社会和行业受益，让生活更美好的生活平台。</p>\r\n<p>最后，祝福所有腾讯的兄弟姐妹们身体健康和家庭幸福。</p>\r\n<p>Tony</p>\r\n<p>2014-03-19&lsquo;</p>\r\n</blockquote>\r\n<p>【本文转自于网易科技】</p>\r\n</div>', NULL, 0, 9, 'false');
INSERT INTO `kor_production` VALUES (2, '土豪是怎么给10万民工做另类APP的?', 'Essay', 'divcss', 'Joebon', '2014-03-23 09:03:03', '<div class="con_title">\r\n<p><span>这么多年我们好不容易学会的一点点互联网产品的「标准」在这里统统不适用：互联网产品讲究用户体验？但在这里，它只需要强迫用户；互联网创业讲究专注，可它偏偏就什么都做；互联网公司需要开放，但在这里，前提却是要把用户圈在围墙里。</span></p>\r\n</div>\r\n<div class="con_txt clx">\r\n<div id="post-txt">\r\n<p><img class="aligncenter" src="http://image.woshipm.com/wp-files/2014/03/9c48e019507242cafcbccf871b7a2db7.jpg" alt="" width="425" height="255" /></p>\r\n</div>\r\n</div>', '<div class="con_title">\r\n<p><span style="font-size: 11px;">这么多年我们好不容易学会的一点点互联网产品的「标准」在这里统统不适用：互联网产品讲究用户体验？但在这里，它只需要强迫用户；互联网创业讲究专注，可它偏偏就什么都做；互联网公司需要开放，但在这里，前提却是要把用户圈在围墙里。</span></p>\r\n</div>\r\n<div class="con_txt clx">\r\n<div id="post-txt">\r\n<p><img class="aligncenter" src="http://image.woshipm.com/wp-files/2014/03/9c48e019507242cafcbccf871b7a2db7.jpg" alt="" width="425" height="255" /></p>\r\n<p>&nbsp;</p>\r\n<p>上周，我约了两个朋友吃饭，一位是VC,另一位是正在创业的我的大学同学。</p>\r\n<div>\r\n<p>&nbsp;先介绍下这位同学，富二代出身，很喜欢钻研互联网，自己也能写写代码。家里开着一家大型劳务派遣公司，在西部某市有一个大型园区，园区里建了七八十个集中宿舍，手下10万民工都吃住在园区。</p>\r\n<p>他先做了需求分析：痛点很多，一是员工太多，每个月发工资，现金堆满了整个屋子，很土很不安全；其次，管理难度极大，随便通知个什么事都要用大喇叭绕着园区广播，还不能保证每个人都能收到；还有就是员工生活实在太枯燥&hellip;&hellip;但说到底，他最大的痛点就是&mdash;&mdash;老子发的工资一半都被这些民工花在周围小卖铺、网吧和各种网络陷阱、电信陷阱里了，凭什么？能不能把发出去的工资再赚回来，甚至让他们再帮我多赚点钱？</p>\r\n<p>顺着这个思路，这位「思想家」设计了以下产品：</p>\r\n<p>1、强制要求每位员工必须安装这款App。不装？每月工资发到App里的指定账户，谁敢不装？注意，这一步，是后面很多功能的前提。</p>\r\n<p>2、在App里实现群组通知功能，未接受到群组信息的有提示反馈；</p>\r\n<p>3、对用户提供海量的电影、短视频、音乐和电子书浏览、下载功能，包月付费；</p>\r\n<p>4、提供O2O周边生活服务。园区距离市区很远，工人买东西不方便，但只要在App中提需求，东西几小时内就会送到（园区本身每天有很多车在园区与市区间穿梭），用账户结算；</p>\r\n<p>5、提供IM功能。包括园区内部沟通和交友、婚恋。在局域网Wi-Fi上屏蔽其它类似应用的接口。收费模式参照其它婚恋网站；</p>\r\n<p>6、在App内提供积分墙，但奖励是现金，直接打进账户。每天用群组通知要求用户必须下载某个应用（行政命令＋现金诱惑）。试想，10万用户刷榜，指哪打那，那还不是想让哪个App上TOP榜哪个就肯定能上？</p>\r\n<p>7、针对VC提出的受众规模问题，思想家提出，可以在10万人园区完成后，复制此模式到各类大型工厂，让一个个局域网之间打通。到时候无非是吸引各个劳务派遣公司入股，怎么分成的问题了。</p>\r\n<p>8、所有从账户提现的行为，考虑加收2%～5%手续费。</p>\r\n<p>听完，VC和我都不明觉厉。这是一款活生生的综合了互联网金融、企业服务、娱乐、O2O、SNS和刷榜的超级应用啊。但总觉得哪里不对劲，这样亮瞎双眼的产品真的可以做吗？可思想家同学说，这不是设想，其实项目已经快开发完了，初步测算下来，能把发出去的工资收回5%～25%。换句话说，仅这一个园区每个月就能收入四五千万，这还不算额外的刷榜收入。</p>\r\n<p>跟思想家聊完，我们想了很多。这么多年我们好不容易学会的一点点互联网产品的「标准」在这里统统不适用：互联网产品讲究用户体验？但在这里，它只需要强迫用户；互联网创业讲究专注，可它偏偏就什么都做；互联网公司需要开放，但在这里，前提却是要把用户圈在围墙里。而根源，<strong>就是在这个案例里，用户不是用户，是「肉鸡」；App开发者也不是开发者，而是警察和老板。</strong></p>\r\n<p>在这样一个用户能被任意管制、规定和屏蔽的大局域网里，「你问我流量入口有多牛？要看你对用户强奸有多深；不用讲什么用户体验，老板命令它代表我的心。」</p>\r\n<p>说回来，像这样的一款产品终究是一个奇葩产品，你也许很难遇到它。但不得不说，<strong>像这样想问题的企业却有很多，其中还不乏大企业，你能想到某些互联网巨头，它们所做的一切不都是想把用户圈在自己的围墙里，希望用一己之力来满足用户的所有需求吗？它们恨的只是自己没有周扒皮那么强而已。说到底，开放和封闭，正是当前中国互联网的主要矛盾，也是决定未来谁赢谁输的关键。</strong></p>\r\n<p>来源：钛媒体</p>\r\n</div>\r\n</div>\r\n</div>', NULL, 0, 11, 'false');
INSERT INTO `kor_production` VALUES (3, '2011欧莱雅校园市场策划大赛', 'Experience', '', 'Joebon', '2014-03-23 09:03:20', '<p>除了理发，男士也需要美发服务吗？是否需要为男士设立专门的美发沙龙以便让他们感觉更加自在呢？怎样才能让男士更愿意走进美发沙龙解决其&ldquo;面子问题&rdquo;？ 4月26日，来自北大、清华和复旦等六所名校的学生在&ldquo;2011欧莱雅校园市场策划大赛&rdquo;上为此展开了一番唇抢舌战，为博得男性消费者的芳心而用尽浑身解数。</p>\r\n<dl><dt><img src="http://p1.yokacdn.com/pic/beauty/ppl/2011/U242P1T1D457022F9DT20110429150714.jpg" alt="对外经济贸易大学V.I.E作方案演示" width="439" height="248" /></dt><dd>对外经济贸易大学V.I.E作方案演示</dd></dl>\r\n<p>连续举办十九届，市场营销界的 &ldquo;世界杯&rdquo;久负盛名</p>', '<p><span style="font-size: 11px;">除了理发，男士也需要美发服务吗？是否需要为男士设立专门的美发沙龙以便让他们感觉更加自在呢？怎样才能让男士更愿意走进美发沙龙解决其&ldquo;面子问题&rdquo;？ 4月26日，来自北大、清华和复旦等六所名校的学生在&ldquo;2011欧莱雅校园市场策划大赛&rdquo;上为此展开了一番唇抢舌战，为博得男性消费者的芳心而用尽浑身解数。</span></p>\r\n<dl><dt><img src="http://p1.yokacdn.com/pic/beauty/ppl/2011/U242P1T1D457022F9DT20110429150714.jpg" alt="对外经济贸易大学V.I.E作方案演示" /></dt><dd>对外经济贸易大学V.I.E作方案演示</dd></dl>\r\n<p>连续举办十九届，市场营销界的 &ldquo;世界杯&rdquo;久负盛名</p>\r\n<p>欧莱雅集团以营销和品牌管理著称，被誉为市场营销和品牌管理的&ldquo;商学院&rdquo;，由其于1993年发起并主办的&ldquo;欧莱雅校园市场策划大赛，是全球最著名的大学学生间的一项国际性营销和品牌管理赛事，参赛者主要为大学高年级的本科和硕士生，他们三人一组在比赛中扮演品牌经理的角色，在综合考虑产品性质、品牌风格、市场环境等诸多因素的基础上，为一个具体的品牌做出最具创意和可执行性的营销方案。</p>\r\n<p>自2003年进入中国以来，欧莱雅校园市场策划大赛已面向国内知名高校的市场营销类学生成功举办了九届，受到了国内高校及市场营销领域专家的高度评价。由于赛事的高水准和案例的多样性以及实践性，该赛事被国内包括复旦大学在内的多所知名高校列为市场营销专业的&ldquo;必修课&rdquo;，同时，该赛事也为市场营销类学科提供了具有实践意义的教学工具。</p>\r\n<dl><dt><img src="http://p1.yokacdn.com/pic/beauty/ppl/2011/U242P1T1D457023F9DT20110429150731.JPG" alt="欧莱雅（中国）CEO为冠军队V.I.E颁奖" /></dt><dd>欧莱雅（中国）CEO为冠军队V.I.E颁奖</dd></dl>\r\n<p>600人报名，36人突围</p>\r\n<p>今年的&ldquo;欧莱雅校园市场策划大赛&rdquo;要求参赛选手大胆想象并设计全新的男士美发沙龙体验，针对欧莱雅专业男士美发品牌开发系列相关产品，并拟定产品推广宣传方案。</p>\r\n<p>今年共有来自北京大学、清华大学、复旦大学、上海交通大学、浙江大学、对外经济贸易大学等六所高校近600名学生报名，经过层层筛选，最终，由36名学生所组成的12支团队进入到决赛。通过前期欧莱雅集团组织的&ldquo;赛前集训&rdquo;，决赛选手了解了真实商战中品牌营销的流程和关键因素，学习获得了大量鲜活生动的市场营销案例。</p>\r\n<p>决赛现场，通过前期充分和精心的准备，各队选手纷纷展示了他们为欧莱雅专业男士美发品牌制定的各具创意和可执行性的男士美发沙龙实践方案以及系列产品包装和设计，激情饱满的演讲、精彩纷呈的方案以及面对评委发问沉着冷静的回答，赢得了现场评审团的啧啧称赞。</p>\r\n<p>经过上午的半决赛和下午的总决赛，最终对外经济贸易大学的V.I.E团队摘得了此次比赛的国内桂冠，他们将代表中国大陆参加6月在巴黎举行的全球总决赛，与来自世界各地其它44个国家和地区的冠军队伍一决高下。这将是中国选手自2003年参赛以来连续第九年为问鼎全球总冠军而发起冲刺。</p>\r\n<dl><dt><img src="http://p1.yokacdn.com/pic/beauty/ppl/2011/U242P1T1D457024F9DT20110429150738.JPG" alt="副总裁为最佳传播策略奖颁奖" /></dt><dd>副总裁为最佳传播策略奖颁奖</dd></dl>\r\n<p>大胆想象 模拟实战</p>\r\n<p>不少欧莱雅校园市场策划大赛的&ldquo;老战友&rdquo;也来到现场观战，去年中国区冠军团队的成员之一&mdash;&mdash;来自北京大学的曾雨珅接受采访时说：&ldquo;当时我的团队中有两位都不是市场营销相关专业的同学，是这个比赛让我从对市场策划一无所知到充满热爱。从作为&ldquo;神秘顾客&rdquo;走访柜台，到决赛巴黎领略各国团队的风采及文化差异，我觉得这个比赛类似一个半命题论文，让我们领略大公司在品牌操作和市场营销方面长处的同时，最大限度地给了我们发挥想象和实践创意的空间。对我来说它是让我对市场工作产生热爱的舞台！&rdquo;曾雨珅还告诉记者，去年比赛结束后团队三人就约好&ldquo;一定要一起到欧莱雅来实习&rdquo;，而今年她即将于7月为作为管理培训生正式成为加入欧莱雅，从事自己所热爱的市场工作。</p>\r\n<dl><dt><img src="http://p1.yokacdn.com/pic/beauty/ppl/2011/U242P1T1D457025F9DT20110429150745.JPG" alt="CEO贝瀚青与入选决赛的代表队" /></dt><dd>CEO贝瀚青与入选决赛的代表队</dd></dl>\r\n<p>最终，来自对外经济贸易大学的V.I.E团队凭借极具创意的策划和缜密的思维将冠军收入囊中，获得了唯一一张通往法国巴黎总决赛的入场券。此外，亚军和季军分别由北京大学Homme Trendsetter团队和复旦大学La Vinga团队摘得。同时，复旦大学该团队还获得了本次比赛的最佳传播策略奖。</p>\r\n<p>创新招聘 可持续发展人才</p>\r\n<p>事实上，校园市场策划大赛已成为校园精英进入欧莱雅集团的重要通途之一。校园赛事是欧莱雅独创的招聘方式。从1993年开始，欧莱雅集团就开创了一系列专门针对市场营销、工业、研发、商业等一些列充满活力的国际商业竞赛，以鼓励年轻人释放潜能，发展职业技能，在轻松有趣的过程中发现职业机会。2010年全新推出的&ldquo;欧莱雅在线职业之旅&rdquo;（REVEAL by L&rsquo;OR&Eacute;AL）更突破了校园赛事的传统模式，为学生提供了一个在线的交互式平台为他们提供三维评估以及个人情况洞察。这一系列赛事为学生提供了逼真而宝贵的商业经历和实践机会，为其就业和今后的职业发展做了很好的铺垫。在招聘人才之前通过创新型赛事发现人才、培养人才，用人先育人，欧莱雅在人才管理上强调可持续发展。</p>\r\n<p>在中国，自2003年进入比赛以来，近20％的欧莱雅管理培训生来自该比赛的参赛者。</p>\r\n<p>2010届管理培训生，现任职于巴黎欧莱雅品牌市场部的Matthew Dong就是通过该赛事进入欧莱雅并在公司迅速成长的代表之一。2008年他作为对外经济贸易大学参赛队的代表通过比赛和欧莱雅结缘，目前已是巴黎欧莱雅品牌市场部的一员。他表示：&ldquo;在欧莱雅校园市场策划大赛得到的历练，无论是对于公司文化的了解，还是对化妆品行业的认识，都成为他加入欧莱雅的重要因素。&rdquo;</p>\r\n<p>欧莱雅中国CEO贝瀚青先生表示：&ldquo;作为全球化妆品行业的领导者，欧莱雅不仅要满足，也要预测消费者需求。因此，我们的品牌和市场经理必须时刻保持敏锐的市场洞察力和持续的创新能力，这在消费者需求极具多样性且快速变化的中国市场上尤其如此。欧莱雅校园市场策划大赛为选手们搭建了一个展示营销才华和创新能力的舞台，也让欧莱雅从中发掘年轻的营销才俊，为我们的人才储备库补充新鲜血液。而比赛中所需的团队精神，也是欧莱雅的核心文化和价值之一。&rdquo;</p>', NULL, 7, 12, 'false');
INSERT INTO `kor_production` VALUES (4, '互联网实战作品 - “以梦为马”网站', 'Work', 'divcss', 'Joebon', '2014-03-23 09:03:13', '<p>&ldquo;以梦为马&rdquo;网站是一个基于<strong>JavaScript/CSS/Ajax/ThinkPHP</strong>等技术的以职业生涯记录与分享、求职准备、职业生涯规划为主题的网站，网站前期设计开发<strong>历时半年</strong>，团队成员由半年前的仅仅<strong>1</strong>人发展到目前一共<strong>9</strong>人，利用课余时间开发完成，目前处于<strong>内测调试阶段</strong>。</p>\r\n<p>暂时访问链接：<a href="http://korbin.hk128.lfidc.net">http://korbin.hk128.lfidc.net</a></p>', '', 'http://korbin.hk128.lfidc.net', 6, 25, 'false');
INSERT INTO `kor_production` VALUES (5, '啊啊啊啊啊啊啊啊啊啊啊啊啊啊', 'Essay', 'divcss', 'Joebon', '2014-04-07 20:04:23', '<p>啊啊啊啊啊啊啊啊啊啊</p>', '<p>啊啊啊啊啊啊啊啊</p>', NULL, 0, 1, 'false');
INSERT INTO `kor_production` VALUES (6, 'dsfsdfsdf', 'Essay', 'divcss', 'Joebon', '2014-04-07 20:04:22', '<p>sdfsdfsdfsd</p>', '<p>sdfsdfsd</p>', NULL, 0, 2, 'false');
INSERT INTO `kor_production` VALUES (7, 'sdfsdfsdfsdf', 'Essay', 'divcss', 'Joebon', '2014-04-07 20:04:34', '<p>sdfsdfsdfsd</p>', '<p>sdfsdfsdfsdf</p>', NULL, 0, 0, 'false');
INSERT INTO `kor_production` VALUES (8, 'ddddddddddddddddddddddd', 'Essay', 'divcss', 'Joebon', '2014-04-07 20:04:46', '<p>dddddddddddddddddddddddddddddd</p>', '<p>dddddddddddddddddddddddddd</p>', NULL, 0, 0, 'false');
INSERT INTO `kor_production` VALUES (9, 'dddfffffffffffff', 'Essay', 'divcss', 'Joebon', '2014-04-07 21:04:57', '<p>ffffffffffffffffffffffffffff</p>', '<p>dddddddddddddd</p>', NULL, 0, 0, 'false');
INSERT INTO `kor_production` VALUES (10, 'ddddddddsssssssssssss', 'Essay', 'divcss', 'Joebon', '2014-04-07 21:04:39', '<p>ddddddddddddffffffffffff</p>', '<p>ssssssssssssssssss</p>', NULL, 0, 0, 'false');
INSERT INTO `kor_production` VALUES (11, 'testbyjoebon', 'Essay', 'divcss', 'Joebon', '2014-04-08 09:04:32', '<p>testbyjoebon</p>', '<p>testbyjoebon</p>', NULL, 0, 0, 'false');
INSERT INTO `kor_production` VALUES (12, 'aaaaaaaaaaaaaa', 'Essay', 'divcss', 'Joebon', '2014-04-08 09:04:35', '<p>aaaaaaaaaaaaa</p>', '<p>aaaaaaaaaaaa</p>', NULL, 0, 0, 'false');
INSERT INTO `kor_production` VALUES (13, 'ccccccccccccccc', 'Essay', 'divcss', 'Joebon', '2014-04-08 09:04:13', '<p>ccccccccccccccc</p>', '<p>cccccccccccccccccc</p>', NULL, 0, 0, 'false');
INSERT INTO `kor_production` VALUES (14, 'cccccccccccccccccccccc', 'Essay', 'divcss', 'Joebon', '2014-04-08 09:04:15', '<p>ccccccccccccccccc</p>', '<p>cccccccccccccccccccc</p>', NULL, 0, 0, 'false');
INSERT INTO `kor_production` VALUES (15, 'eeeeeeeeeeeeeeeee', 'Essay', 'divcss', 'Joebon', '2014-04-08 09:04:18', '<p>eeeeeeeeeeeeeeeeeeeeeeeeeeeeee</p>', '<p>eeeeeeeeeeeeeeeee</p>', NULL, 0, 0, 'false');
INSERT INTO `kor_production` VALUES (16, 'ffffffffffffffffffffffffffffff', 'Essay', 'divcss', 'Joebon', '2014-04-08 09:04:51', '<p>fffffffffffffffff</p>', '<p>fffffffffffffffffff</p>', NULL, 0, 0, 'false');
INSERT INTO `kor_production` VALUES (17, 'sssssss', 'Essay', 'divcss', 'Joebon', '2014-04-08 10:04:40', '<p>sssssssssssssss</p>', '<p>sssssssssssssssss</p>', NULL, 0, 0, 'false');
INSERT INTO `kor_production` VALUES (18, 'sssssssss', 'Essay', 'divcss', 'Joebon', '2014-04-08 10:04:38', '<p>ssssssssssssssss</p>', '<p>ssssssssssssssss</p>', NULL, 0, 1, 'false');
INSERT INTO `kor_production` VALUES (19, 'sssssssssfffff', 'Essay', 'divcss', 'Joebon', '2014-04-08 10:04:53', '<p>ffffffffffffffssssssssssssss</p>', '<p>ssssssssssssssfffffffffffffff</p>', NULL, 0, 1, 'false');
INSERT INTO `kor_production` VALUES (20, 'aaaaaaaaaaassssssssssss', 'Essay', 'divcss', 'testUser', '2014-04-08 11:04:44', '<p>aaaaaaaaaaasssssssss</p>', '<p>aaaaaaaaaaaasssssssssssssss</p>', NULL, 0, 2, 'false');
INSERT INTO `kor_production` VALUES (21, 'mmmmmmmmmd', 'Essay', 'divcss', 'Joebon', '2014-04-08 11:04:12', '<p>mmmmmmmmmmmmd</p>', '<p>mmmmmmmmmmmmd</p>', NULL, 0, 8, 'false');

-- --------------------------------------------------------

-- 
-- 表的结构 `kor_tag`
-- 

CREATE TABLE `kor_tag` (
  `tagid` int(11) NOT NULL auto_increment,
  `tagdetail` varchar(50) NOT NULL,
  PRIMARY KEY  (`tagid`),
  UNIQUE KEY `tagdetail` (`tagdetail`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=19 ;

-- 
-- 导出表中的数据 `kor_tag`
-- 

INSERT INTO `kor_tag` VALUES (1, '会计');
INSERT INTO `kor_tag` VALUES (2, '测试工程师');
INSERT INTO `kor_tag` VALUES (3, '软件工程师');
INSERT INTO `kor_tag` VALUES (4, '啊啊啊啊啊啊啊啊啊啊啊啊啊啊');
INSERT INTO `kor_tag` VALUES (5, 'dsfsdfsdf');
INSERT INTO `kor_tag` VALUES (6, 'ddddddddsssssssssssss');
INSERT INTO `kor_tag` VALUES (7, 'testbyjoebon');
INSERT INTO `kor_tag` VALUES (8, 'aaaaaaaaaaaaaa');
INSERT INTO `kor_tag` VALUES (9, 'eeeeeeeeeeeeeeeee');
INSERT INTO `kor_tag` VALUES (10, 'ffffffffffffffffffffffffffffff');
INSERT INTO `kor_tag` VALUES (11, 'sssssss');
INSERT INTO `kor_tag` VALUES (12, 'sssssssss');
INSERT INTO `kor_tag` VALUES (13, 'sssssssssfffff');
INSERT INTO `kor_tag` VALUES (14, '产品经理');
INSERT INTO `kor_tag` VALUES (15, 'testUser');
INSERT INTO `kor_tag` VALUES (16, 'aaaaaaaaaaassssssssssss');
INSERT INTO `kor_tag` VALUES (17, 'mmmmmmmmmd');
INSERT INTO `kor_tag` VALUES (18, 'korbinzhao');

-- --------------------------------------------------------

-- 
-- 表的结构 `kor_tagrelation`
-- 

CREATE TABLE `kor_tagrelation` (
  `relationid` int(11) NOT NULL auto_increment,
  `tagid` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  PRIMARY KEY  (`relationid`),
  KEY `tagid` (`tagid`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

-- 
-- 导出表中的数据 `kor_tagrelation`
-- 

INSERT INTO `kor_tagrelation` VALUES (1, 0, 0);
INSERT INTO `kor_tagrelation` VALUES (2, 0, 0);
INSERT INTO `kor_tagrelation` VALUES (3, 0, 14);
INSERT INTO `kor_tagrelation` VALUES (4, 0, 15);
INSERT INTO `kor_tagrelation` VALUES (5, 10, 16);
INSERT INTO `kor_tagrelation` VALUES (6, 11, 17);
INSERT INTO `kor_tagrelation` VALUES (7, 12, 18);
INSERT INTO `kor_tagrelation` VALUES (8, 13, 19);
INSERT INTO `kor_tagrelation` VALUES (9, 16, 20);
INSERT INTO `kor_tagrelation` VALUES (10, 15, 20);
INSERT INTO `kor_tagrelation` VALUES (11, 17, 21);

-- --------------------------------------------------------

-- 
-- 表的结构 `kor_thinkform`
-- 

CREATE TABLE `kor_thinkform` (
  `id` smallint(4) unsigned NOT NULL auto_increment,
  `title` varchar(255) NOT NULL,
  `content` varchar(255) NOT NULL,
  `create_time` int(11) unsigned NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- 导出表中的数据 `kor_thinkform`
-- 


-- --------------------------------------------------------

-- 
-- 表的结构 `kor_user`
-- 

CREATE TABLE `kor_user` (
  `userno` int(11) NOT NULL auto_increment,
  `username` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `password` varchar(80) default NULL,
  `motto` varchar(100) default '       ',
  `organization` varchar(50) default NULL,
  `reputation` int(10) NOT NULL,
  `vitality` int(10) NOT NULL,
  `authority` varchar(10) NOT NULL default 'user',
  PRIMARY KEY  (`userno`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

-- 
-- 导出表中的数据 `kor_user`
-- 

INSERT INTO `kor_user` VALUES (1, 'zbin', '1031700027@qq.com', 'e10adc3949ba59abbe56e057f20f883e', '淡定前行~', '华南理工大学', 0, 0, 'user');
INSERT INTO `kor_user` VALUES (2, 'Joebon', 'change1202@163.com', 'e10adc3949ba59abbe56e057f20f883e', '要好好加油哦~', 'Dalian University of Technology', 0, 0, 'user');
INSERT INTO `kor_user` VALUES (3, 'korbin', 'korbin@qq.com', 'e10adc3949ba59abbe56e057f20f883e', ' 等了那么久，2014终于来了！', '大连理工大学', 0, 0, 'user');
INSERT INTO `kor_user` VALUES (4, 'xiaowenjie', 'isABigSB@SB.com', 'e10adc3949ba59abbe56e057f20f883e', 'It is my motto.', '北京大学', 0, 0, 'user');
INSERT INTO `kor_user` VALUES (5, 'pengshulin', 'sdfgsd@sfsd.com', 'e10adc3949ba59abbe56e057f20f883e', 'I am dream catcher. ', '大连理工大学', 0, 0, 'user');
INSERT INTO `kor_user` VALUES (6, 'User', 'sdfdsf@sdf.com', 'e10adc3949ba59abbe56e057f20f883e', 'Run with the dream. ', NULL, 0, 0, 'user');
INSERT INTO `kor_user` VALUES (7, 'panhongmin', 'sdfdsfws@sdf.com', 'e10adc3949ba59abbe56e057f20f883e', 'It is my motto ', NULL, 0, 0, 'user');
INSERT INTO `kor_user` VALUES (8, 'testUser', 'sdfsd@sdfs.com', 'e10adc3949ba59abbe56e057f20f883e', '       ', NULL, 0, 0, 'user');
INSERT INTO `kor_user` VALUES (9, 'korbinzhao', 'korbinzhao@hotmail.c', 'e10adc3949ba59abbe56e057f20f883e', '       ', NULL, 0, 0, 'user');
